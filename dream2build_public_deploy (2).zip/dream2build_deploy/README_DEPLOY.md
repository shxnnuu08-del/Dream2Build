# Dream2Build AI — Public Deployment

This package is prepared as a Flask web service. The app binds to `0.0.0.0` and reads the hosting provider's `PORT`, so it can run behind a public web host.

## Render
1. Create a new Web Service on Render.
2. Upload/push this project to a Git repository and select it.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 120`
5. Add `SECRET_KEY` as a generated secret (the included `render.yaml` does this automatically if using Blueprint deployment).

## Important database note
The demo uses SQLite (`dream2build.db`). SQLite is suitable for a hackathon demo, but a free/ephemeral web service should not be treated as durable production storage. For persistent multi-user production data, move the database to PostgreSQL.

## Demo account
The supplied backend seeds the demo account defined in `db.py`. Change/remove that seed before exposing the site publicly if you do not want a public demo credential.
